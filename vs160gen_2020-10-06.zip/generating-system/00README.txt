2020/10/06 @kl files in this directory are for generating vs1 6.0


This directory contains files for generating a VS1 6.0 system.  They are:

  g00-create-dasd.cmd
  g01-init-dasd-dlib.jcl
  g02-allocate-dlibs-nonstarter.jcl
  g02-allocate-dlibs-starter.jcl
  g03-load-dlibs.jcl
  g04-init-dasd-misc.jcl
  g05-allocate-sysres.jcl
  g06-jobcard-nonstarter.jcl
  g06-jobcard-starter.jcl
  g07-stage1.jcl
  g09-parmlib.jcl
  g10-proclib.jcl

A more detailed explanation of each is below.  Run the jobs in numerical order.
The starter system will automatically start a class A initiator in P0.  You
must start a writer to printer 00E and a writer to punch 00D by issuing the
VS1 STARTF command for each:

  sf ,00e
  sf ,00d

Once you have placed the first job in the reader using the Hercules "devinit"
command:

  devinit 00c generating-system/g01-init-dasd-dlib.jcl

issue a STARTF command to 00C to start the reader:

  sf ,00c

You don't need to start the reader for each job, just the first one.


g00-create-dasd.cmd
  A Windows command file to run the Hercules "dasdload" program to create
  the three DASD files fgen60.149.cckd (FGEN60, the new sysres), fdlb60.14a.cckd
  (FDLB60, the VS1 6.0 DLIB volume), and page83.451.cckd (PAGE83, which will
  contain the new VS1 system's page data set).  Adjust the file system paths
  as appropriate.  If you're a Linux user, for the moment you're on your own.

g01-init-dasd-dlib.jcl
  An IEHDASDR job to initialize FDLB60, the new DLIB volume.  The volume should
  have been created and mounted before this job is run.

g02-allocate-dlibs-nonstarter.jcl
g02-allocate-dlibs-starter.jcl
  Jobs to allocate DLIB data sets on FDLB60, the new DLIB volume.  Run one or
  the other, depending on your circumstances:  the "nonstarter" version if
  you're using MVS or some other system that supports VSAM as your generating
  system, the "starter" version if you're using the VS1 6.0 starter system as
  your generating system.  The "nonstarter" version creates a VSAM user catalog
  and catalogs the new VS1 6.0 DLIB data sets in it; the "starter" version
  catalogs the DLIB data sets in the VS1 6.0 starter system's system catalog.
  Note that the "nonstarter" job has an IEHPROGM step to uncatalog any existing
  DLIB data sets in the system catalog, and will get either a 0 return code or
  an 8 return code depending on whether or not the DLIBs were previously cataloged.

g03-load-dlibs.jcl
  An IEBCOPY job to reload the DLIBs to the FDLB60 DLIB DASD volume from the
  ZDLF60 tape.

g04-init-dasd-misc.jcl
  An IEHDASDR job to initialize FGEN60, the new sysres volume, and PAGE83, the
  new page data set volume.  The volumes should have been created and mounted
  before this job is run.

g05-allocate-sysres.jcl
  A job to allocate system data sets on the new FGEN60 sysres volume.

g06-jobcard-nonstarter.jcl
g06-jobcard-starter.jcl
  Jobs to modify the "JOBCARD" stage 1 sysgen macro in SYS1.AGENLIB.  Run one
  or the other, depending on your circumstances:  the "nonstarter" version if
  you're using MVS or some other system that supports VSAM as your generating
  system, the "starter" version if you're using the VS1 6.0 starter system as
  your generating system.  The "starter" version adds a "JOBCAT" DD statement
  to each stage 2 job, the "nonstarter" version doesn't.

g07-stage1.jcl
  The VS1 6.0 stage 1 job stream.  Review and modify as appropriate.  When run,
  it will create the stage 2 job stream as class B punched output.  After the
  stage 2 deck has been created, copy the punched output created by the stage 1
  job to be the next file:

g08-stage2.jcl
  You will create this file from the punched output from job g07-stage1.jcl
  Submit the jobs to VS1.  There will be 15 jobs, G08GEN1 through G08GEN15,
  and they will be held.  Release and run each job in sequence (for example,
  "a g08gen1").

g09-parmlib.jcl
  An IEBUPDTE job to add initialization parm members to SYS1.PARMLIB on the
  new FGEN60 system.

g10-proclib.jcl
  An IEBUPDTE job to add procedures to SYS1.PROCLIB on the new FGEN60 system.


At this point, you should be ready to IPL the new FGEN60 system.  During the
first IPL, when you receive the message:

  IEA101A SPECIFY SYSTEM AND/OR SET PARAMETERS FOR RELEASE 06.0  OS/VS1

reply:

  r 00,'auto=cold'

to cold start.  You only need to cold start the first time.  Note that the
reply must be entered exactly as above, with enclosing quotes; NIP's console
communication routines aren't too smart.  During subsequent IPLs after the
first one, when the system has been cold started, you can press ENTER
in response to the IEA101A message.


The stage 2 deck originally created by running the stage 1 job is in the
directory as "z08-stage2.jcl".  You don't need to run that job stream, it's
there for your reference.








